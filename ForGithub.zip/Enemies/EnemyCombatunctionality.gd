extends CombatFunctionality

class_name EnemyCombatFunctionality

# enemy depended stat
@export var contactDamage = 5

@export var texture:Texture2D

@export var collisionshape:Shape2D
@export var collisionTransform:Transform2D
@export var enemySprite: Texture2D
