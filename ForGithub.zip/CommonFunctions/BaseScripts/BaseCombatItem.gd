extends Resource

class_name BaseItem

func applyItemEffect(_bullet:BaseBullet):
	pass
