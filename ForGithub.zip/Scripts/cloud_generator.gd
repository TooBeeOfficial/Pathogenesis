extends Node

func _ready() -> void:
	$ParallaxLayer.motion_mirroring = get_viewport().get_camera_2d().get_viewport_rect().size
	$ParallaxLayer/ColorRect.size = get_viewport().get_camera_2d().get_viewport_rect().size
