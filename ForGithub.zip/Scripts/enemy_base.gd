extends RigidBody2D

class_name Enemy

@export var BaseCombat:EnemyCombatFunctionality

var _PlayerPos = Vector2.ZERO
var player

func OnDeath():
	queue_free()
	pass

func takeDamage(amount):
	if BaseCombat.isHittable == true:
		$HitParticle.emitting = true
		BaseCombat.TakeDamage(amount,self)

func _ready() -> void:
	var players = get_tree().get_nodes_in_group("Player")
	if players.size() > 0:
		player = players[0]
	getPlayerPos(((player as Player).global_position))

func getPlayerPos(pos)->Vector2:
	_PlayerPos = pos
	return position

func OnCollision(body: Node) -> void:
	if body is Player:
		body.TakeDamage(BaseCombat.contactDamage)

func _process(_delta: float) -> void:
	look_at((player as Player).global_position)
	position = lerp(position,(player as Player).global_position,_delta)
