extends Resource
class_name BasePlayerBuff

func applyBuff(_player:Player):
	pass
