extends Node2D

@export var segmentLenght = 10
var segmentPositions:Array[Vector2]
@export var distance = 20
@export var Width = 20
@export var texture:Texture
@export var offsett = Vector2(0,0)
@export var newshader = "implement shader"

func _ready() -> void:
	$Line2D.clear_points()
	$Line2D.width = Width
	if texture != null:
		$Line2D.texture = texture
	
	for index in segmentLenght:
		$Line2D.add_point(getParentLocalPosition(),index)
		segmentPositions.append(getParentLocalPosition())

func getParentLocalPosition() -> Vector2:
	return to_local(get_parent().global_position + (offsett.rotated(get_parent().global_rotation)))

func _process(_delta: float) -> void:
	segmentPositions[0] = getParentLocalPosition()
	for index in range(1,segmentLenght):
		segmentPositions[index] = Vector2(lerp(segmentPositions[index],segmentPositions[index-1] + Vector2.DOWN * distance, 0.01 + _delta))
	for point in range(segmentLenght):
		$Line2D.set_point_position(point, segmentPositions[point])
