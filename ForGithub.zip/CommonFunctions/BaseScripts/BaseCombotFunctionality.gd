extends Resource
class_name CombatFunctionality

# used for animating flashing effect on hit
var flash_timer := 0.0
# duration of the flash, if character has eye frames setit to that
var flash_duration
# how fast it should flash between flashes
var current_interval := 0.5
var next_flash_time := 0.0
var flashing := false
var visibility := true
# Base stats for Combat
# upgradable stats
@export var MaxHealth = 50
@export var speed = 200
@export var fireRate = 2.5
@export var armor = 0
# variable stats
@export var health = 50
@export var shoot_cooldown = 0
# Player buff items
var playerBuffs:Array[BasePlayerBuff]
# bullet to shoot, Modular
var bulletUpgrades:Array[BaseItem] = []
@export var bulletScene: PackedScene
# Used to delay hits taken, Eye frames
var isHittable = true
var isBurning = false
var burnShader = preload("res://Shaders/BurnEffect.gdshader")
var burn_amount := 0.0
var burn_speed := 0.3  # how fast to burn (units per second)

func start_flash_on_hit(character:Node2D):
	flash_timer = 0.0
	next_flash_time = 0.0
	current_interval = 0.5
	flashing = true
	character.visible = true
	character.modulate.a = 1.0

func flash(delta, character:Node2D):
	flash_timer += delta
	# Increase flashing speed as time progresses
	var t = clamp(flash_timer / flash_duration, 0, 1)
	current_interval = lerp(0.5, 0.05, t)
	# reset alpha to max once its finished
	if flash_timer >= flash_duration:
		character.modulate.a = 1.0
		flashing = false
		return
	# adjust between full and low opacity
	if flash_timer >= next_flash_time:
		visibility = !visibility
		character.modulate.a = 1.0 if visibility else 0.3
		next_flash_time = flash_timer + current_interval

func TakeDamage(amount: int, character:Node2D):
	# if character doesnt eyeframes
	if isHittable == true:
		start_flash_on_hit(character)
		# only player will have eye frames
		if character is Player:
			isHittable = false
		health -= amount
		if character is Enemy:
			print_debug(health)
		# on death call characters' death function
		if health <= 0:
			character.OnDeath()
			pass

func spawnBullet(globalSpawnLocation:Vector2, inheretedBy, isPlayer):
	# if firing on cooldown, don't fire
	if shoot_cooldown <= 0:
		var bullet = bulletScene.instantiate(PackedScene.GEN_EDIT_STATE_DISABLED)
		bullet.global_position = globalSpawnLocation
		# used for collision detection
		# does not collide with the firing character
		(bullet as BaseBullet).isPlayerBullet(isPlayer)
		for upgrade in bulletUpgrades:
			# Seperate Player item uprades from BulletEffect upgrades
			if upgrade is BulletEffect:
				(bullet as BaseBullet).BulletEffects.append(upgrade as BaseItem)
		(bullet as BaseBullet).calculateColor()
		inheretedBy.add_sibling(bullet)
		# add a cap to firerate
		shoot_cooldown = clampf(2.0/fireRate,0.05,50.0)

func applyShaderToTexture(sprite:Sprite2D,shader: Shader):
	if not sprite or not shader:
		return
	var shader_material := ShaderMaterial.new()
	shader_material.shader = shader
	sprite.material = shader_material
