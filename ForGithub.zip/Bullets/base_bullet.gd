extends RigidBody2D

class_name BaseBullet

var bulletStats:BaseBulletStats = preload("res://CommonFunctions/BaseScripts/BaseBulletStats.gd").new()

@export var collisionShape:CollisionShape2D
@export var BulletEffects:Array[BulletEffect] = []

var player
var newRotation
var isPlayer = false

func _init() -> void:
	if bulletStats.sprite != null:
		$Sprite2D.texture = bulletStats.sprite
	
	if collisionShape != null:
		$CollisionShape2D.shape = collisionShape
		$Area2D/CollisionShape2D2.shape = collisionShape
	

func isPlayerBullet(isBulletFromPlayer: bool = true):
	isPlayer = isBulletFromPlayer

func calculateColor():
	var calRed = clamp(bulletStats.bulletDamage * bulletStats.bulletDamageMult, 0, 255) / 255
	$Sprite2D.modulate = Color(calRed,1-calRed,1-calRed,1)

func _ready() -> void:
	var players = get_tree().get_nodes_in_group("Player")
	if players.size() > 0:
		player = players[0]
	global_rotation = (player as Player).global_rotation
	newRotation = Vector2.RIGHT.rotated((player as Player).global_rotation)

func _process(delta: float) -> void:
	global_position +=  newRotation.normalized() * delta * bulletStats.bulletSpeed * bulletStats.bulletSpeedMult

func calcBulletDamage() -> int:
	return bulletStats.bulletDamage * bulletStats.bulletDamageMult

func applyBulletEffects(body):
	for effect in BulletEffects:
		print_debug(effect)
		effect.applyItemEffect(self)
		await effect.applyBulletEffect(body,get_parent().get_tree())

func bulletCollided(body: Node) -> void:
	# Seperate player bullets from enemy bullets
	if body is Player:
		if isPlayer == false:
			body.takeDamage(calcBulletDamage())
			applyBulletEffects(body)
			queue_free()
	elif body is Enemy:
		if isPlayer == true:
			body.takeDamage(calcBulletDamage())
			applyBulletEffects(body)
			queue_free()
