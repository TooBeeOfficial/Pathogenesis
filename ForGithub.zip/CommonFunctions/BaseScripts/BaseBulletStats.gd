extends Resource

class_name BaseBulletStats

@export var sprite: Texture2D
@export var bulletDamage = 5
@export var bulletSpeed = 300
@export var bulletDamageMult = 1
@export var bulletSpeedMult = 1
