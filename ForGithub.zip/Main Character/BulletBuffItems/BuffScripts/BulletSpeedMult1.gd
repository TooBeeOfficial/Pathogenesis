extends BaseItem
class_name SpeedMultUpgrade

@export var speedMult = 1.5

func applyItemEffect(bullet:BaseBullet):
	bullet.bulletStats.bulletSpeedMult *= speedMult
	pass
