extends BaseItem
class_name DamageMultUpgrade

@export var DamageMult = 1.5

func applyItemEffect(bullet:BaseBullet):
	print_debug(bullet.bulletStats.bulletDamageMult)
	bullet.bulletStats.bulletDamageMult *= DamageMult
	pass
