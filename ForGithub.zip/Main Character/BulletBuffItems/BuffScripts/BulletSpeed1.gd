extends BaseItem

class_name SpeedUpgrade
@export var speed = 50

func applyItemEffect(bullet:BaseBullet):
	bullet.bulletStats.bulletSpeed += speed
	pass
