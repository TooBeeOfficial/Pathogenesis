extends Node2D

@export var shootTime = 5
var mat
var charge := 0.0
var charging: bool = true

func _ready() -> void:
	$Timer.wait_time = shootTime
	mat = $Sprite2D.material

func shootParticle():
	$HitParticle.emitting = true
	$Area2D/CollisionShape2D.disabled = false

func disableCollision():
	$Area2D/CollisionShape2D.disabled = true

var timer := 0.0
var going_up := true

func _process(delta):
	timer += delta
	if timer > shootTime:
		timer = 0.0  # Restart loop

	# Progress 0.0 → 1.0 over shoot_time seconds
	var progress = timer / shootTime
	$Sprite2D.material.set_shader_parameter("charge_progress", progress)
