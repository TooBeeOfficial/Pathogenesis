extends BaseItem

class_name DamageUpgrade
@export var damage = 3

func applyItemEffect(bullet:BaseBullet):
	bullet.bulletStats.bulletDamage += damage
	pass
