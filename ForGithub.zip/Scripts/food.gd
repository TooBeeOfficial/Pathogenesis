extends Area2D

class_name Food
# default amount used to charge portal
var portalFuelmount = 10
var isEaten = false
var finalPosition:Vector2 = Vector2.ZERO
@export var duration: float = .5

func _ready() -> void:
	$CPUParticles2D.color = Color(0,1,0,.5)

func setFinalDestinationPoint(newPos:Vector2) -> void:
	finalPosition = newPos
	
	var tween = create_tween()
	tween.tween_property(self, "position",finalPosition,duration).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)

func OnBodyEneter(body: Node) -> void:
	if body is Player:
		body.IncrementPortalSpawnPercent(portalFuelmount)
		$CPUParticles2D.emitting = true
		isEaten = true;
		
	if isEaten == true:
		await get_tree().create_timer($CPUParticles2D.lifetime+.05).timeout
		queue_free()
