extends BasePlayerBuff
class_name PlayerSpeedBuff

@export var speed = 50

func applyBuff(player:Player):
	player.BaseCombat.speed += speed
	pass
