extends BasePlayerBuff
class_name PlayerHealthBuff

@export var health = 5

func applyBuff(player:Player):
	player.BaseCombat.MaxHealth += health
	pass
