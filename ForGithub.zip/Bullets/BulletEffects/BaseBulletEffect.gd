extends BaseItem
class_name BulletEffect

func applyBulletEffect(body:Node2D, tree:SceneTree):
	pass
