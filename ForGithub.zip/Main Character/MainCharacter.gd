extends CharacterBody2D
class_name Player

# combat stats and functionality
@export var BaseCombat:CombatFunctionality = preload("res://CommonFunctions/BaseScripts/BaseCombotFunctionality.gd").new()
# used for movement, instead of only clicking
# player can also hold to go to the destination
var isMouseHeld = false
# once player reaches threshold ex. 100 spawn a location portal
var portalSpawnPercent = 0
# used for movement and movement animation
var isMoving: bool = false
# Scales used for animation
@export var MaxScale = 2.7
@export var MinScale = 2.3
# on start reset scale in case changed
const NormalScale = 2.5
# Used for tween animation for apendages of enemy
var baseScale = Vector2(MinScale, MinScale)
var pulseScale = Vector2(MaxScale, MaxScale)
var pulseDuration = 1
var tween
# For spawning new locations
@export var Location: PackedScene
@export var LocationSpawnRadius = 500
@export var LocationMinSapwnDistance = 250
# when hit camera shake
@export var randomShakeStrengh = 50
@export var shakeFade = .3
var randomNumberForShake = RandomNumberGenerator.new()
var shakeStrengh = 0

func _init() -> void:
	scale.y = NormalScale
	scale.x = NormalScale

func addUpgrade(upgrade:BaseItem):
	BaseCombat.bulletUpgrades.append(upgrade)

# adds it to upgrade list in case we change scenes
# applies the buff immidietly
func addPlayerBuff(buff:BasePlayerBuff):
	BaseCombat.playerBuffs.append(buff)
	buff.applyBuff(self)

# start animation pulse
func _start_pulsing():
	tween = get_tree().create_tween()
	tween.set_loops()
	# animation goes from minimum scale to maximum scale
	# then goes backwards
	tween.tween_property(self, "scale", pulseScale, pulseDuration).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	tween.tween_property(self, "scale", baseScale, pulseDuration).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)

# reset strengh
func ShakeCamera():
	shakeStrengh = randomShakeStrengh

func _stop_pulsing(resetScale:bool):
	if tween:
		tween.kill()
		# reset scales while moving
		if resetScale == true:
			scale = Vector2(NormalScale,NormalScale)
		elif resetScale == false:
			scale = Vector2(MaxScale,MinScale)

func _ready():
	# Set starting values
	# make it same time as eye frames
	BaseCombat.flash_duration = $EyeFrames.wait_time
	BaseCombat.flash_timer = 0.0
	BaseCombat.next_flash_time = BaseCombat.current_interval
	modulate.a = 1.0
	_start_pulsing()

# Used for gameplay loop to create a new portal once threshold is reached
func IncrementPortalSpawnPercent(amount):
	portalSpawnPercent += amount
	# max portal amount cant exceed threshold
	# once it exceeds spawn portal and keep exceeding amount
	if portalSpawnPercent >= 100:
		# Keep Exceeding fuel source
		portalSpawnPercent = portalSpawnPercent % 100
		# initialize new pawning location and its initial position range
		var newLocation = Location.instantiate()
		var newPosition = Vector2(randi_range(-LocationSpawnRadius,LocationSpawnRadius), randi_range(-LocationSpawnRadius,LocationSpawnRadius))
		# Spawn LocationMinSapwnDistance away from player characters current position
		if abs(newPosition.x) < LocationMinSapwnDistance:
			newPosition.x = LocationMinSapwnDistance * sign(newPosition.x)
		if abs(newPosition.y) < LocationMinSapwnDistance:
			newPosition.y = LocationMinSapwnDistance * sign(newPosition.y)
		# Add players global position to make it spawn around player
		# instead of root scene
		newPosition += global_position
		newLocation.global_position = newPosition
		# Used call defer to fix error: "Can't change this state while flushing queries"
		call_deferred("add_sibling", newLocation)
		# print_debug(get_parent().get_child_count())

# reduce "food"
func DecrementPortalSpawnPercent(amount):
	portalSpawnPercent -= amount
	if portalSpawnPercent <= 0:
		# prevent portal from going into negatives
		portalSpawnPercent = 0

func OnDeath():
	pass

func TakeDamage(amount):
	if BaseCombat.isHittable == true:
		# activate hit effectand start timer
		$HitParticle.emitting = true
		BaseCombat.TakeDamage(amount,self)
		$EyeFrames.start()

# called by timer timeout signal
# used for adding eye frames
func EyeFrameEnd():
	BaseCombat.isHittable = true

# used to create camera shake effect
func randomOffset() -> Vector2:
	return Vector2(randomNumberForShake.randf_range(-shakeStrengh,shakeStrengh),randomNumberForShake.randf_range(-shakeStrengh,shakeStrengh))

func _process(delta: float) -> void:
	# once player gets hit activate flashing effect
	if BaseCombat.flashing == true:
		BaseCombat.flash(delta,self)

func _physics_process(delta: float) -> void:
	# decrease cooldown with delta time
	# used for limiting fire per second
	if BaseCombat.shoot_cooldown > 0:
		BaseCombat.shoot_cooldown -= delta
	if Input.is_action_pressed("Shoot"):
		BaseCombat.spawnBullet($BulletSpawnLocation.global_position,self,true)
	# > 0 apply shake and slowly fade it out
	if shakeStrengh > 0:
		shakeStrengh = lerpf(shakeStrengh,0,shakeFade + delta)
		$Sprite2D/Camera2D.offset += randomOffset()
	# if camera is out of position and shake animation finished reset its offset
	if ($Sprite2D/Camera2D.offset as Vector2).length() > 0 and shakeStrengh <= 0.01:
		$Sprite2D/Camera2D.offset = Vector2.ZERO
	# 8 way movement
	var input_direction = Input.get_vector("Left", "Right", "Up", "Down")
	isMoving = !input_direction.is_zero_approx()
	if isMoving == true:
		_start_pulsing()
	if isMoving == false:
		_stop_pulsing(isMoving)
	velocity = input_direction * BaseCombat.speed
	# player looks at mouse for immersion
	look_at(get_global_mouse_position())
	move_and_slide()
