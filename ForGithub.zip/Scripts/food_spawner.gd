extends StaticBody2D

const _MaximumFoodSpawn = 10
var currentFoodSpawned = 0

# used for checking how much time has passed and if spawner needs to spawn food
var time_elapsed = 0
# Maximum range to spawn the food items
@export var SpawnRadius = 100
@export var SpawnMargin = 50
@export var FoodScene: PackedScene

# Used for "animating" the food spawning animation
@export var minScale = .9
@export var maxScale = 1.1

func _process(delta: float) -> void:
	time_elapsed += delta
	scale = Vector2((lerpf(1.0,minScale,time_elapsed) as float),(lerpf(1.0,minScale,time_elapsed as float)))
	if time_elapsed > 1 and _MaximumFoodSpawn != currentFoodSpawned:
		# increment to check if spawner needs to be destroyed/freed
		currentFoodSpawned += 1
		# reset timer for every second to prevent from spawning food too early
		time_elapsed = 0
		scale = Vector2(lerpf(1,maxScale,time_elapsed),lerpf(1,maxScale,time_elapsed))
		# spawn food
		var newFood = FoodScene.instantiate(PackedScene.GEN_EDIT_STATE_INSTANCE)
		var spawnPosition = Vector2(randi_range(SpawnRadius * -1 ,SpawnRadius),randi_range(SpawnRadius * -1,SpawnRadius))
		# Clamp minimum values for negative and positive to -25 and 25 respectively
		# to prevent food spawning inside the spawner
		# regardless of sign(+/-) if x position is less then 25 make it 25 then multiply it with its sign
		if abs(spawnPosition.x) < SpawnMargin:
			spawnPosition.x = SpawnMargin * sign(spawnPosition.x)
		# regardless of sign(+/-) if y position is less then 25 make it 25 then multiply it with its sign
		if abs(spawnPosition.y) < SpawnMargin:
			spawnPosition.y = SpawnMargin * sign(spawnPosition.y)
		# make it spawn relative to the foodSpawner instead of parent
		spawnPosition += global_position
		newFood.global_position = global_position
		(newFood as Food).setFinalDestinationPoint(spawnPosition)
		# print_debug(newFood.position - global_position)
		# adds it a a sibling to not be effected by the scale changes
		add_sibling(newFood)
	if _MaximumFoodSpawn == currentFoodSpawned:
		# Destroy spawner
		$".".queue_free()
		pass
