extends RigidBody2D

class_name LocationPortal

@onready var mat := $Sprite2D.material as ShaderMaterial

func _init() -> void:
	modulate = Color(randf_range(0,1),randf_range(0,1),randf_range(0,1),1)
	pass

func _process(_delta):
	var t = Time.get_ticks_msec() / 2000.0
	mat.set_shader_parameter("time", t)

func _on_mouse_entered() -> void:
	scale = Vector2(1.2,1.2)
	pass # Replace with function body.

func _on_mouse_exited() -> void:
	scale =Vector2(1,1)
	pass # Replace with function body.
